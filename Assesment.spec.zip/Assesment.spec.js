
const { test } = require('@playwright/test');
const HomePage = require('../pages/HomePage');
const CorporateTrainingTab = require('../pages/CorporateTrainingTab');

test('Automation practice', async ({ page }) => {
  const homePage = new HomePage(page);
  await homePage.navigateToEdureka();
  await homePage.searchForCourse();

  const corporateTraining = new CorporateTrainingTab(page);
  await corporateTraining.navigateToCorporateTrainingTab();
  await corporateTraining.switchToCorporateTrainingTab();
  await page.pause();

  
});