
class CorporateTrainingTab {
  constructor(page) {
    this.page = page;
    this.CorporateTrainingTabSelector =  page.getByRole('tab', { name: 'Corporate Training' });
    this.selectTrainingNeed = '//select[@id="taningForm.ControlSelect1"]';
   
    
    this.CorporateTrainingLinkSelector = '(//a[@id="tabs-batchtabel-tab-third"])[1]';
  }

  async navigateToCorporateTrainingTab() {
    await this.page.goto('https://www.edureka.co/aws-developer-certification-training');
  }

  async switchToCorporateTrainingTab() {
    await this.page.click(this.CorporateTrainingLinkSelector);
    await this.page.dblclick(this.selectTrainingNeed);
   
    this.page.selectOption(this.selectTrainingNeed, { label: 'For Myself' });
    await this.page.evaluate(()=>{
      window.scrollBy(0,7500);
   
       
   });
   await this.page.pause();

}
}


module.exports = CorporateTrainingTab;
























