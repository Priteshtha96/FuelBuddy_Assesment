
  class HomePage {
    constructor(page) {
      this.page = page;
     
      this.SearchBox = '//input[@aria-label="Enter Course, Category or keyword"][1]';
      this.DropDownSelector = '//ul[@id="search-results"]//li//a[@href="/aws-developer-certification-training"]';
     
    }
  
    async navigateToEdureka() {
      await this.page.goto('https://www.edureka.co/');
    }
  
    async searchForCourse() {
      await Promise.all([
        this.page.fill(this.SearchBox, 'AWS'),
        this.page.waitForSelector(this.SearchBox, { state: 'visible' }),
      ]);
  
      const dropDownHandle = await this.page.waitForSelector(this.DropDownSelector);
  
      await dropDownHandle.scrollIntoViewIfNeeded();
      await dropDownHandle.click();
      
    }
  }
  
  module.exports = HomePage;
  